<meta http-equiv="Content-Type" content="text/html, charset=utf-8">

<?php

$con = mysqli_connect("localhost","root","root") or die("Não foi possível conectar com o servidor de dados!")

?>
