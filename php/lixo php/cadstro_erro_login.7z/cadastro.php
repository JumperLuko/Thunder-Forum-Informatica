<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastro</title>
    </head>
    <body>
        <form action="processarCadastro.php" method="post">
            Login: <input type="text" name="login" required/><br />
            Senha: <input type="password" name="senha" required/><br />
            <input type="submit" />
        </form>
    </body>
</html>
