<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        Erro!
        <?php
            $erro = $_GET["erro"];
            echo($erro);
        ?>
    </body>
</html>
