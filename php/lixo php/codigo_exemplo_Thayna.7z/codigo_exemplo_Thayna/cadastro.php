<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="processarCadastro.php" method="post">
            Login: <input type="text" name="login" /><br />
            Senha: <input type="password" name="senha" /><br />
            <input type="submit" />
        </form>
    </body>
</html>
