<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="cadastro.php">Cadastre-se</a><br />
        <a href="mostrar.php">Mostrar</a><br />
        <a href="login.php">Login</a>
        
    </body>
</html>
