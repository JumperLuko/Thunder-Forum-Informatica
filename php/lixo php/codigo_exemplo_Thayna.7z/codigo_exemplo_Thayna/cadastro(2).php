<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="processarCadastro.php" method="post" >
            login: <input type="text" name="login" required/><br/>
            senha: <input type="password" name="senha" required/><br/>
            <input type="submit" />
        </form>
    </body>
</html>
